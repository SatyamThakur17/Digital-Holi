let active = false;

async function getTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

async function init() {
  const tab = await getTab();
  if (!tab || !tab.url || !tab.url.includes('meet.google.com')) {
    document.getElementById('main').style.display = 'none';
    document.getElementById('not-meet').style.display = 'block';
  }
}

document.getElementById('toggle').addEventListener('click', async () => {
  const tab = await getTab();
  if (!tab) return;

  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        if (window.__holiInjected && window.__holiToggle) {
          window.__holiToggle();
          return 'toggled';
        }
        return 'not_injected';
      }
    });

    const result = results?.[0]?.result;

    if (result === 'not_injected') {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ['content.js']
      });
      active = true;
    } else {
      active = !active;
    }
  } catch(e) {
    const err = document.getElementById('err');
    err.style.display = 'block';
    err.textContent = '⚠️ Reload the Meet tab & try again.';
    return;
  }

  const btn = document.getElementById('toggle');
  const badge = document.getElementById('badge');
  if (active) {
    btn.className = 'main-btn stop';
    btn.textContent = '✕ Stop Holi';
    badge.className = 'badge on';
    badge.innerHTML = '<div class="dot"></div><span>Active</span>';
  } else {
    btn.className = 'main-btn start';
    btn.textContent = '🎉 Start Holi!';
    badge.className = 'badge';
    badge.innerHTML = '<div class="dot"></div><span>Off</span>';
  }
});

document.getElementById('clear').addEventListener('click', async () => {
  const tab = await getTab();
  if (!tab) return;
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => { if (window.__holiClear) window.__holiClear(); }
    });
  } catch(e) {}
});

init();
