// Holi Meet - Content Script (fully self-contained)
(function () {
  // Don't inject twice
  if (window.__holiInjected) {
    // Just toggle if already injected
    if (window.__holiToggle) window.__holiToggle();
    return;
  }
  window.__holiInjected = true;

  const COLORS = [
    '#FF3366', '#FF8C00', '#FFE600',
    '#00E676', '#00B0FF', '#E040FB',
    '#FF69B4', '#ffffff'
  ];
  const COLOR_NAMES = [
    'Gulal Red', 'Mango Orange', 'Sunshine Yellow',
    'Panna Green', 'Sky Blue', 'Rose Magenta',
    'Gulabi Pink', 'Shubh White'
  ];

  let currentColor = COLORS[0];
  let isActive = false;
  let isDrawing = false;
  let sprayMode = false;
  let sprayTimer = null;
  let brushSize = 20;
  let mx = 0, my = 0;
  let particles = [];
  let animFrame = null;

  // ── Inject all CSS inline via a <style> tag ─────────────────
  const styleEl = document.createElement('style');
  styleEl.id = 'holi-styles';
  styleEl.textContent = `
    #holi-canvas {
      position: fixed !important;
      top: 0 !important; left: 0 !important;
      width: 100% !important; height: 100% !important;
      z-index: 2147483640 !important;
      pointer-events: none !important;
      display: none;
    }
    #holi-canvas.holi-on { display: block !important; pointer-events: all !important; }
    #holi-cur {
      position: fixed !important;
      width: 26px !important; height: 26px !important;
      border-radius: 50% !important;
      pointer-events: none !important;
      z-index: 2147483647 !important;
      transform: translate(-50%,-50%) !important;
      box-shadow: 0 0 14px 4px rgba(255,255,255,0.4) !important;
      display: none !important;
      transition: background 0.15s !important;
    }
    #holi-cur.holi-on { display: block !important; }
    #holi-bar {
      position: fixed !important;
      bottom: 72px !important;
      left: 50% !important;
      transform: translateX(-50%) !important;
      z-index: 2147483646 !important;
      display: none;
      align-items: center !important;
      gap: 10px !important;
      background: rgba(15,4,36,0.95) !important;
      border: 1px solid rgba(255,255,255,0.18) !important;
      border-radius: 60px !important;
      padding: 10px 18px !important;
      box-shadow: 0 8px 40px rgba(0,0,0,0.7) !important;
      font-family: Arial, sans-serif !important;
      backdrop-filter: blur(10px) !important;
    }
    #holi-bar.holi-on { display: flex !important; }
    .holi-cb {
      width: 32px !important; height: 32px !important;
      border-radius: 50% !important;
      border: 2.5px solid rgba(255,255,255,0.25) !important;
      cursor: pointer !important;
      flex-shrink: 0 !important;
      transition: transform 0.15s, border-color 0.15s !important;
    }
    .holi-cb:hover { transform: scale(1.2) !important; border-color: #fff !important; }
    .holi-cb.holi-active {
      transform: scale(1.28) !important;
      border-color: #fff !important;
      box-shadow: 0 0 14px 3px var(--hc) !important;
    }
    .holi-sep {
      width: 1px !important; height: 26px !important;
      background: rgba(255,255,255,0.18) !important; flex-shrink: 0 !important;
    }
    .holi-btn {
      background: rgba(255,255,255,0.1) !important;
      border: 1px solid rgba(255,255,255,0.2) !important;
      color: #fff !important;
      font-size: 11px !important;
      padding: 5px 12px !important;
      border-radius: 20px !important;
      cursor: pointer !important;
      letter-spacing: 1px !important;
      text-transform: uppercase !important;
      white-space: nowrap !important;
      font-family: Arial, sans-serif !important;
      transition: background 0.2s !important;
    }
    .holi-btn:hover { background: rgba(255,255,255,0.22) !important; }
    #holi-slider {
      -webkit-appearance: none !important;
      width: 64px !important; height: 4px !important;
      border-radius: 2px !important;
      background: rgba(255,255,255,0.3) !important;
      outline: none !important; cursor: pointer !important;
    }
    #holi-slider::-webkit-slider-thumb {
      -webkit-appearance: none !important;
      width: 14px !important; height: 14px !important;
      border-radius: 50% !important;
      background: #fff !important; cursor: pointer !important;
    }
  `;
  document.head.appendChild(styleEl);

  // ── Canvas ───────────────────────────────────────
  const canvas = document.createElement('canvas');
  canvas.id = 'holi-canvas';
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
  document.documentElement.appendChild(canvas);
  const ctx = canvas.getContext('2d');

  // ── Cursor ───────────────────────────────────────
  const cur = document.createElement('div');
  cur.id = 'holi-cur';
  cur.style.background = currentColor;
  document.documentElement.appendChild(cur);

  // ── Toolbar ──────────────────────────────────────
  const bar = document.createElement('div');
  bar.id = 'holi-bar';

  COLORS.forEach((hex, i) => {
    const b = document.createElement('div');
    b.className = 'holi-cb' + (i === 0 ? ' holi-active' : '');
    b.style.cssText = `background:${hex};--hc:${hex};`;
    b.title = COLOR_NAMES[i];
    b.addEventListener('mousedown', e => {
      e.stopPropagation();
      document.querySelectorAll('.holi-cb').forEach(x => x.classList.remove('holi-active'));
      b.classList.add('holi-active');
      currentColor = hex;
      cur.style.background = hex;
    });
    bar.appendChild(b);
  });

  const sep1 = document.createElement('div'); sep1.className = 'holi-sep';
  bar.appendChild(sep1);

  const slider = document.createElement('input');
  slider.type = 'range'; slider.id = 'holi-slider';
  slider.min = 8; slider.max = 50; slider.value = 20;
  slider.title = 'Brush size';
  slider.addEventListener('input', () => brushSize = +slider.value);
  slider.addEventListener('mousedown', e => e.stopPropagation());
  bar.appendChild(slider);

  const sep2 = document.createElement('div'); sep2.className = 'holi-sep';
  bar.appendChild(sep2);

  let sprayBtn = document.createElement('button');
  sprayBtn.className = 'holi-btn'; sprayBtn.textContent = '💨 Spray';
  sprayBtn.addEventListener('mousedown', e => {
    e.stopPropagation();
    sprayMode = !sprayMode;
    sprayBtn.textContent = sprayMode ? '✅ Spray' : '💨 Spray';
    if (!sprayMode) { clearInterval(sprayTimer); sprayTimer = null; }
  });
  bar.appendChild(sprayBtn);

  const clearBtn = document.createElement('button');
  clearBtn.className = 'holi-btn'; clearBtn.textContent = '🗑 Clear';
  clearBtn.addEventListener('mousedown', e => { e.stopPropagation(); clearCanvas(); });
  bar.appendChild(clearBtn);

  const sep3 = document.createElement('div'); sep3.className = 'holi-sep';
  bar.appendChild(sep3);

  const exitBtn = document.createElement('button');
  exitBtn.className = 'holi-btn';
  exitBtn.style.cssText = 'border-color:rgba(255,80,80,0.5)!important;';
  exitBtn.textContent = '✕ Exit';
  exitBtn.addEventListener('mousedown', e => { e.stopPropagation(); deactivate(); });
  bar.appendChild(exitBtn);

  document.documentElement.appendChild(bar);

  // ── Particles ────────────────────────────────────
  class Particle {
    constructor(x, y, col, sz) {
      this.x = x + (Math.random() - 0.5) * sz;
      this.y = y + (Math.random() - 0.5) * sz;
      this.col = col;
      this.r = Math.random() * sz * 0.5 + sz * 0.15;
      this.alpha = 0.85 + Math.random() * 0.15;
      this.vx = (Math.random() - 0.5) * 5;
      this.vy = (Math.random() - 0.5) * 5 - 1.5;
      this.g = 0.13;
      this.life = 1;
      this.decay = Math.random() * 0.02 + 0.01;
    }
    tick() {
      this.vx *= 0.97; this.vy += this.g;
      this.x += this.vx; this.y += this.vy;
      this.life -= this.decay; this.r *= 0.985;
    }
    draw() {
      if (this.r < 0.5) return;
      ctx.save();
      ctx.globalAlpha = Math.max(0, this.life * this.alpha);
      ctx.fillStyle = this.col;
      ctx.shadowColor = this.col; ctx.shadowBlur = 8;
      ctx.beginPath();
      ctx.arc(this.x, this.y, this.r, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
  }

  function splash(x, y, col, n) {
    col = col || currentColor;
    n = n || 30;
    for (let i = 0; i < n; i++) particles.push(new Particle(x, y, col, brushSize));
    ctx.save();
    ctx.globalAlpha = 0.55;
    ctx.fillStyle = col;
    ctx.shadowColor = col; ctx.shadowBlur = 20;
    ctx.beginPath();
    ctx.arc(x, y, brushSize * 0.55 + Math.random() * 5, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  function doSpray(x, y) {
    for (let i = 0; i < 10; i++) {
      const a = Math.random() * Math.PI * 2;
      const d = Math.random() * brushSize * 2;
      ctx.save();
      ctx.globalAlpha = Math.random() * 0.3 + 0.08;
      ctx.fillStyle = currentColor;
      ctx.beginPath();
      ctx.arc(x + Math.cos(a) * d, y + Math.sin(a) * d, Math.random() * 3 + 1, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
  }

  function clearCanvas() {
    particles = [];
    ctx.clearRect(0, 0, canvas.width, canvas.height);
  }

  function loop() {
    for (let i = particles.length - 1; i >= 0; i--) {
      const p = particles[i];
      p.tick(); p.draw();
      if (p.life <= 0) particles.splice(i, 1);
    }
    animFrame = requestAnimationFrame(loop);
  }

  function activate() {
    isActive = true;
    canvas.classList.add('holi-on');
    bar.classList.add('holi-on');
    cur.classList.add('holi-on');
    document.body.style.setProperty('cursor', 'none', 'important');
    // Welcome burst
    const cx = window.innerWidth / 2, cy = window.innerHeight / 2;
    COLORS.forEach((col, i) => {
      setTimeout(() => {
        for (let j = 0; j < 8; j++) {
          const a = (j / 8) * Math.PI * 2;
          splash(cx + Math.cos(a) * 90, cy + Math.sin(a) * 90, col, 12);
        }
      }, i * 90);
    });
    if (!animFrame) loop();
  }

  function deactivate() {
    isActive = false; isDrawing = false;
    clearInterval(sprayTimer); sprayTimer = null;
    canvas.classList.remove('holi-on');
    bar.classList.remove('holi-on');
    cur.classList.remove('holi-on');
    document.body.style.removeProperty('cursor');
    clearCanvas();
  }

  window.__holiToggle = () => isActive ? deactivate() : activate();
  window.__holiClear = clearCanvas;

  // ── Events (capture phase, high priority) ────────
  document.addEventListener('mousemove', e => {
    mx = e.clientX; my = e.clientY;
    if (!isActive) return;
    cur.style.left = mx + 'px';
    cur.style.top = my + 'px';
    if (isDrawing && !sprayMode) splash(mx, my, currentColor, 8);
  }, true);

  document.addEventListener('mousedown', e => {
    if (!isActive) return;
    if (e.target.closest && e.target.closest('#holi-bar')) return;
    e.stopPropagation();
    isDrawing = true;
    splash(mx, my, currentColor, 35);
    if (sprayMode) {
      clearInterval(sprayTimer);
      sprayTimer = setInterval(() => doSpray(mx, my), 25);
    }
  }, true);

  document.addEventListener('mouseup', e => {
    isDrawing = false;
    clearInterval(sprayTimer); sprayTimer = null;
  }, true);

  document.addEventListener('dblclick', e => {
    if (!isActive || (e.target.closest && e.target.closest('#holi-bar'))) return;
    e.stopPropagation();
    for (let b = 0; b < 6; b++) {
      setTimeout(() => splash(e.clientX, e.clientY, COLORS[Math.floor(Math.random() * COLORS.length)], 50), b * 60);
    }
  }, true);

  document.addEventListener('keydown', e => {
    if (!isActive) return;
    const idx = +e.key - 1;
    if (idx >= 0 && idx < COLORS.length) {
      document.querySelectorAll('.holi-cb')[idx]?.dispatchEvent(new MouseEvent('mousedown', { bubbles: false }));
    }
    if (e.key === 'Escape') deactivate();
    if (e.key.toLowerCase() === 'c') clearCanvas();
    if (e.key.toLowerCase() === 's') sprayBtn.dispatchEvent(new MouseEvent('mousedown'));
  }, true);

  window.addEventListener('resize', () => {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
  });

  // Start immediately
  activate();
})();
